# Compile instructions

The paper draft is written as a standard single-column LaTeX article.

## Files

- `paper.tex`: main manuscript
- `references.bib`: BibTeX references
- `figure1_evidence_panel_en.png`: Figure 1, English evidence panel used by the paper
- `../embodied_results/reviewer_defense/`: three-seed robustness tables and reviewer-defense baseline/ablation outputs used in the manuscript
- `../embodied_results/counterfactual_validation/`: explicit push-vs-away counterfactual validation outputs
- `../embodied_results/baseline_comparisons/`: static appearance-only baseline outputs
- `../embodied_results/cpf_sensitivity/`: CPF weight and scale sensitivity outputs
- `../embodied_results/object_state_oracle/`: object-state oracle upper-bound probe for counterintuitive visual scenes
- `../embodied_results/expanded_baselines/`: reward-aligned, object-state, decorrelated visual, causal-distillation, transformer-history, and randomized 3D state probes
- `../embodied_results/final_gap_experiments/`: final multi-seed gap-closing experiments with complex 2D observation learning, learned slot memory, Slot-Attention-lite, Interaction Network state, Q-learning, Transformer world model, and 3D pixel-effect baselines
- `../embodied_results/recurrent_baseline/`: recurrent sensor world-model baseline outputs
- `../embodied_results/memory_ablation/`: memory-scaffold probe ablation outputs
- `major_revision_response.md`: draft response to major-revision reviewer comments
- `future_research_proposal.md`: follow-up research proposal based on the current paper's limitations

## Recommended compile command

Run from the `paper/` directory:

```powershell
$env:Path = "C:\Users\yugen\AppData\Local\Programs\MiKTeX\miktex\bin\x64;" + $env:Path
pdflatex -enable-installer -interaction=nonstopmode paper.tex
bibtex paper
pdflatex -enable-installer -interaction=nonstopmode paper.tex
pdflatex -enable-installer -interaction=nonstopmode paper.tex
```

If `latexmk` is available:

```powershell
latexmk -pdf paper.tex
```

## Notes

- The manuscript uses only English text to avoid CJK LaTeX font requirements.
- This machine now has MiKTeX 25.12 installed through `winget`; `paper.pdf` was successfully generated as an 18-page A4 PDF.
- PyBullet was loaded on this Windows machine from official conda-forge Windows binary packages through `work/vendor_pybullet/env_overlay`; direct-mode connection and 64 by 64 TinyRenderer output were used as the smoke test.
- Required LaTeX packages: `geometry`, `graphicx`, `booktabs`, `amsmath`, `array`, `caption`, `subcaption`, `hyperref`, and `natbib`.
- If the Figure 1 image is moved, update this line in `paper.tex`:

```tex
\includegraphics[width=\linewidth]{figure1_evidence_panel_en.png}
```
